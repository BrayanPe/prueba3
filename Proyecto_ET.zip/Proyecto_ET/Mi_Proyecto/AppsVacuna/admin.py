from django.contrib import admin
from .models import Persona
from .models import Sede

admin.site.register(Persona)

admin.site.register(Sede)