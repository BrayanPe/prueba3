from django.db import models

class Persona(models.Model):
    rut = models.CharField(max_length=9)
    nombre = models.CharField(max_length=35)
    apellidoP=models.CharField(max_length=35)
    apellidoM = models.CharField(max_length=35)
    edad = models.CharField(max_length=3)
    Vacuna = models.CharField(max_length=35)
    fecha = models.DateField()

class Sede(models.Model):
    nombre_sede = models.CharField(max_length=100)
    direccion = models.CharField(max_length=100)
    tipo_sede = models.CharField(max_length=100)
    comuna = models.CharField(max_length=100)
    nombre_vacuna = models.CharField(max_length=100)