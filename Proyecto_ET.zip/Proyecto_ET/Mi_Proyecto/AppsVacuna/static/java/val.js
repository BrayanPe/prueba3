function validar()
{
        nombre_sede = document.formulario.txt_sede.values;
        

}
