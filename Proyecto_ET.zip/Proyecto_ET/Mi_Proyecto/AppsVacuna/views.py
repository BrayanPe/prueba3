from django.shortcuts import render
from django.http import HttpResponse
from AppsVacuna.models import Persona


def index(request):
    return render(request,"index.html")

def ingresar_persona(request):
    return render(request,"ingresar_persona.html")


def busqueda_persona(request):
    return render(request,"busqueda_persona.html") 

def listar_todo(request):
    return render(request,"listar_todo.html")


def eliminar_persona(request):
    return render(request,"eliminar_persona.html")


# Create your views here.

def listar_toda_personas(request):
    personas = Persona.objects.all() 
    contexto = {
        'personas':personas
    }
    return render(request,'listar_todo.html',contexto)
    
def ingreso_persona(request):
    
        rut = request.GET["txr_rut"]
    
    return render(request,"ingresar_persona.html",contexto)
    


def buscar(request):
    if request.GET["txt_rut"]:
        persona = request.GET["txt_rut"]
        persona = Persona.objects.filter(nombre__icontains=persona)
        return render(request,"listar.html",{"persona":persona,"query":persona})
    else:
        mensaje = "Debe ingresar el rut de la persona"
        return HttpResponse(mensaje)


def eliminacion_persona(request):
    if request.GET["txt_rut"]:
        rut_recibido = request.GET["txt_rut"]
        persona = Persona.objects.filter(rut=rut_recibido)
        if producto:
            persona=Persona.objects.get(rut=rut_recibido)
            persona.delete()
            mensaje = "Persona Eliminada..."
        else:
            mensaje = "No existe persona  con ese rut"
    else:
        mensaje = "Debe ingresar un rut para eliminación..."
    return HttpResponse(mensaje)