from django.contrib import admin
from django.urls import path
from AppsVacuna.views import index,ingresar_persona


urlpatterns = [
    path('admin/', admin.site.urls),
    path('listar_todo/',views.listar_todo),
    path('listar_toda_personas/',views.listar_toda_personas),
    path('ingresar_persona/',views.ingresar_persona),
    path('ingreso_persona/',views.ingreso_persona),
    
    path('busqueda_persona/',views.busqueda_persona),
    path('buscar/',views.buscar),
    path('eliminar_persona/',views.eliminar_persona),
    path('eliminacion_persona/',views.eliminacion_persona),
    
    path('',views.index),
]
